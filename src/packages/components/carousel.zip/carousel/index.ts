import Carousel from './carousel'
import CarouselItem from './CarouselItem'
// Carousel.item = CarouselItem
export { Carousel, CarouselItem }
import './style/index.css'