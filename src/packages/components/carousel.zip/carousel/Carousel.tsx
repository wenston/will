import { computed, defineComponent, h, provide, renderSlot, ref, getCurrentInstance, onMounted, CSSProperties, PropType, watch } from 'vue'
import IndicatorItem from './indicator'
interface Props {
    count: number;
    style: CSSProperties;
    options: object;
}

export default defineComponent({
    name: 'Carousel',
    // components: { IndicatorItem },
    props: {
        options: {
            type: Object,
            default: () => ({
                "duration": 2000,
                'autoPlay': true,
                "type": 'row',
                "indicator": true,
                "moveTime": 1000,
                'flip': true,
            })
        },

    },
    setup(props, ctx) {
        provide('getUid', getUid)
        const uid: any = ref([])
        function getUid<T>(v: T): void {
            uid.value.push(v)
        }

        const instance: any = getCurrentInstance()
        const index = ref(0)
        let t: any
        const isT = ref(false)
        // 定时
        const autoPlay = () => {
            if (props.options.autoPlay) {
                t = setInterval(() => {
                    if (uid.value.length - 1 > index.value && !isT.value) {
                        index.value++
                    } else {
                        isT.value = true
                        if (index.value > 0) {
                            index.value--
                        } else {
                            isT.value = false
                        }
                    }
                }, props.options.duration || 2000);
            };
        }
        const style: any = ref('')
        // 监听
        watch(() => index.value, (v) => {

            if (props.options.type == 'row') {
                style.value = `transform: translate3d(-${instance?.refs.Carousel.clientWidth * v}px, 0px, 0px);transition-duration: ${props.options.moveTime || 1000}ms`
            } else {
                style.value = `transform: translate3d(0px, -${instance?.refs.Carousel.clientHeight * v}px, 0px);transition-duration: ${props.options.moveTime || 1000}ms;`
            }
        })
        // 样式
        const cls: any = computed(() => {
            let s = []
            // s.push('Carousei')
            if (props.options.type == 'column') {
                s.push('w-carousei-column')
            }
            return {
                class: s
            }
        })
        const isFlipUp = ref('none')
        const isFlipDown = ref('none')
        // 鼠标移出
        function mouseLeave(e: any) {
            // index.value = 0
            isFlipUp.value = 'none'
            isFlipDown.value = 'none'
            autoPlay()
            document.onmousemove = null
            e.preventDefault()
        }
        const right = ref()
        const left = ref()
        // 鼠标移入
        function mouseover(e: any) {
            if (props.options.flip) {
                if (index.value > 0) {
                    isFlipDown.value = 'block'
                } else {
                    isFlipDown.value = 'none'
                }
                if (index.value < uid.value.length - 1) {
                    isFlipUp.value = 'block'
                } else {
                    isFlipUp.value = 'none'
                }

            } else {
                isFlipUp.value = 'none'
                isFlipDown.value = 'none'
            }
            clearInterval(t)
            e.preventDefault()
        }
        onMounted(() => {
            autoPlay()
            indicatorS()
            if (props.options.flip) {
                if (props.options.type == 'row') {
                    right.value = ['w-carouse_right_left', 'w-carouse-right_r']
                    left.value = ['w-carouse_right_left', 'w-carouse-left_r']
                } else {
                    right.value = ['w-carouse_right_left', 'w-carouse-right_c']
                    left.value = ['w-carouse_right_left', 'w-carouse-left_c']
                }
            }
        })

        const indicatorContent: any = ref('')
        function indicatorItem() {
            return uid.value.map((item, i: Number) => {
                return <IndicatorItem v-bind:item={i} v-bind:key={i}></IndicatorItem>
            })
        }

        function indicatorS() {
            if (props.options.indicator) {
                // console.log(indicatorItem());

                indicatorContent.value = <div class='w-indicator'></div>
            } else {
                indicatorContent.value = ''
            }
        }
        const CarouseiBox = ref('w-carouseiBox')
        const Carousei = ref('w-carousei')

        // 鼠标按下
        function startFn(e: any) {
            clearInterval(t)
            document.onmousemove = function (ev: any) {
                if (props.options.type == 'row') {
                    let en = instance?.refs.Carousel.clientWidth * index.value + (e.offsetX - ev.offsetX)
                    if (e.offsetX - ev.offsetX > 0) {
                        if (Math.abs(e.offsetX - ev.offsetX) > 10) {
                            if (index.value < uid.value.length - 1)
                                index.value++
                            document.onmousemove = null
                        } else {
                            if (index.value < uid.value.length - 1) {
                                style.value = `transform: translate3d(-${en}px, 0px, 0px);`
                            }
                        }
                    } else {
                        if (Math.abs(e.offsetX - ev.offsetX) > 10) {
                            if (index.value > 0) {
                                index.value--
                                document.onmousemove = null
                            }
                        } else {
                            if (index.value > 0) {
                                style.value = `transform: translate3d(-${en}px, 0px, 0px);`
                            }
                        }
                    }
                } else {
                    let en = instance?.refs.Carousel.clientHeight * index.value + (e.offsetY - ev.offsetY)
                    if (e.offsetY - ev.offsetY > 0) {
                        if (Math.abs(e.offsetY - ev.offsetY) > 10) {
                            if (index.value < uid.value.length - 1)
                                index.value++
                            document.onmousemove = null
                        } else {
                            if (index.value < uid.value.length - 1) {
                                style.value = `transform: translate3d(0px, -${en}px, 0px);`
                            }
                        }
                    } else {
                        if (Math.abs(e.offsetY - ev.offsetY) > 10) {
                            if (index.value > 0) {
                                index.value--
                                document.onmousemove = null
                            }
                        } else {
                            if (index.value > 0) {
                                style.value = `transform: translate3d(0px, -${en}px, 0px);`
                            }
                        }
                    }
                }
            }
            e.preventDefault()

        }

        // 鼠标松开
        function endFn(e: any) {
            document.onmousemove = null
            e.preventDefault()
        }

        function PageUp() {
            if (index.value < uid.value.length - 1) {
                index.value++
            } else {
                isFlipUp.value = 'none'
            }
        }
        function PageDown() {
            if (index.value > 0) {
                index.value--
            } else {
                isFlipDown.value = 'none'
            }
        }
        return () => (<div ref='Carousel' onMouseout={mouseLeave} onMouseover={mouseover} onMousedown={startFn}
            onMouseup={endFn} class={Carousei.value}>
            <div style={style.value} class={CarouseiBox.value}  {...cls.value}>
                {ctx.slots.default?.()}
            </div>
            <div class={right.value} style={{ display: isFlipUp.value }} onClick={PageUp}>&gt;</div>
            <div class={left.value} style={{ display: isFlipDown.value }} onClick={PageDown}>&lt;</div>
            {indicatorContent.value}
        </div >)

    }
})