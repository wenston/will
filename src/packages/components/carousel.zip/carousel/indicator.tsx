import { computed, defineComponent, h, ref, inject } from 'vue'
export default defineComponent({
    name: 'IndicatorItem',
    props: ["item"],
    setup(props, ctx) {
        const cls = computed(() => {
            if (props.item) {
                return {
                    class: ['w-indicator-item', 'w-indicator-item-active']
                }
            } else {
                return {
                    class: ['w-indicator-item']
                }
            }
        })
        return () => <div {...cls.value}> {ctx.slots.default?.()}</div>
    }
})